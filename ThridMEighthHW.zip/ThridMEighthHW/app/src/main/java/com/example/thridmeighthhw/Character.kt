package com.example.thridmeighthhw

import java.io.Serializable

data class Character(
    var image: String?=null,
    var life: String?=null,
    var name: String?=null
) : Serializable
